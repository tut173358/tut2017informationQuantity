package s4.b173358;
import java.lang.*;

public class Hello {
    public static void main(String[] args) {
	System.out.println("hello..(buggy)");
    }
}
